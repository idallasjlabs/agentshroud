# Pipeline Gap Analysis — All Data Flow Paths

**Date:** 2026-03-08 14:20 UTC
**Method:** Code trace of every entry/exit point in the gateway

---

## Data Flow Map

```
INBOUND (user → agent):
  Telegram getUpdates → telegram_proxy._filter_inbound_updates() → bot
  Telegram webhook → webhook_receiver.process_webhook() → bot
  MCP tool call → /mcp/proxy → mcp_proxy.process_tool_call() → bot

OUTBOUND (agent → user):
  Bot sendMessage → /telegram-api/ → telegram_proxy._filter_outbound() → Telegram API
  Bot MCP result → /mcp/result → mcp_proxy.process_tool_result() → agent
  LLM API → /v1/{path} → llm_proxy.proxy_messages() → Anthropic API

DIRECT (gateway → Telegram, bypasses proxy):
  Disclosure notice → _send_disclosure() → api.telegram.org DIRECT
  Command blocked notice → _notify_collaborator_command_blocked() → api.telegram.org DIRECT
  User blocked notice → _notify_user_blocked() → api.telegram.org DIRECT
  Approval queue buttons → approval_queue.send_notification() → api.telegram.org DIRECT
  Egress buttons → egress_notifier.notify_pending() → api.telegram.org DIRECT

TUNNEL:
  HTTP CONNECT → http_proxy.py → WebProxy allowlist check → destination
```

---

## INBOUND Analysis

### ✅ Telegram getUpdates (telegram_proxy._filter_inbound_updates)
- [x] Middleware pipeline (RBAC, ContextGuard, MultiTurn) — lines 298-319
- [x] PII sanitization — lines 323-341
- [x] Collaborator command blocking — lines 283-295
- [x] Owner exemption (middleware logs but doesn't block) — line 305
- [ ] ❌ **Does NOT call pipeline.process_inbound()** — uses middleware_manager directly
- [ ] ❌ **No PromptGuard check** — injection detection is in the pipeline, not middleware
- [ ] ❌ **No EncodingDetector** — base64/ROT13 payloads pass through undetected inbound

**FINDING G-1:** The getUpdates inbound path uses `middleware_manager.process_request()` which runs RBAC + ContextGuard + MultiTurn + ToolChain. But it does NOT call `pipeline.process_inbound()` which runs PromptGuard + EncodingDetector + TrustManager. A prompt injection in a Telegram message is NOT detected on the getUpdates path.

### ✅ Telegram Webhook (webhook_receiver.process_webhook)
- [x] pipeline.process_inbound() — line 163 ✅
- [x] pipeline.process_outbound() on response — line 217 ✅
- [x] Session isolation — lines 147-196
- [x] Collaborator tracking — lines 147-160

**VERDICT:** Webhook path uses the FULL pipeline. This is correct.

### ✅ MCP Tool Calls (/mcp/proxy)
- [x] mcp_proxy.process_tool_call() — has its own security inspection
- [x] PII scanning of parameters
- [x] Permission checks
- [x] iMessage allowlist check
- [x] Approval queue integration
- [ ] ❓ Does NOT call pipeline.process_inbound() — uses mcp_proxy's own checks

**VERDICT:** MCP proxy has its own security layer. Acceptable — tool calls are a different flow than messages.

---

## OUTBOUND Analysis

### ✅ Telegram sendMessage (telegram_proxy._filter_outbound) — JUST FIXED
- [x] XML block filtering ✅
- [x] Credential blocking ✅
- [x] PII sanitization ✅ (NEW — commit cff5911)
- [x] Full pipeline (process_outbound) ✅ (NEW — commit cff5911)
- [x] Fail-closed for non-owner ✅ (NEW)

**VERDICT:** Fixed. Full pipeline now runs.

### ⚠️ MCP Results (/mcp/result)
- [x] mcp_proxy.process_tool_result() — PII/credential scanning
- [ ] "Results are never blocked — only redacted and audited" (comment on line 635)
- [ ] ❌ Does NOT call pipeline.process_outbound()

**FINDING G-2:** MCP tool results are "never blocked." If a tool returns PII or injected content, it's redacted but still forwarded. This is by design (tools need their results) but creates a channel where redacted-but-still-present data flows to the agent.

### ⚠️ LLM API Proxy (/v1/{path})
- [x] IP allowlist (Docker network only) — lines 2447-2453
- [ ] ❌ Does NOT run any security pipeline on responses
- [ ] ❌ LLM responses go straight through to the agent
- [ ] llm_proxy is never instantiated anyway (dead endpoint)

**FINDING G-3:** If/when the LLM proxy is activated, it has NO outbound security filtering. LLM responses would bypass PII detection, injection scanning, everything. Currently dead code but a future risk.

---

## DIRECT TELEGRAM CALLS (Bypass Everything)

### 🔴 G-4: Gateway sends messages DIRECTLY to api.telegram.org

Three methods in telegram_proxy.py send messages directly to the Telegram API, bypassing the outbound security pipeline entirely:

| Method | Line | Content | Risk |
|--------|------|---------|------|
| `_send_disclosure()` | 358 | Disclosure notice text | LOW — hardcoded text |
| `_notify_collaborator_command_blocked()` | 388 | Blocked command notice | LOW — hardcoded text |
| `_notify_user_blocked()` | 429 | Block reason message | 🟡 MEDIUM — includes `result.reason` which could contain internal info |

Also in other modules:
| Source | Content | Risk |
|--------|---------|------|
| `approval_queue` (send_notification) | Approval request details | 🟡 MEDIUM — includes tool name, description |
| `egress_notifier` (notify_pending) | Egress domain info | LOW — domain names only |

**FINDING G-4:** These direct Telegram API calls bypass the OutboundInfoFilter. The `_notify_user_blocked()` method is the riskiest — it forwards `result.reason` which could contain module names, detection details, or internal security architecture info.

---

## TUNNEL Analysis

### ✅ HTTP CONNECT (http_proxy.py)
- [x] Domain allowlist (mode=allowlist) ✅
- [x] DNS blocklist check via WebProxy ✅
- [x] api.telegram.org removed from allowlist ✅ (commit ce91062)
- [ ] ❌ No content inspection (by design — CONNECT is encrypted tunnel)

**VERDICT:** Acceptable. CONNECT tunnels are encrypted; content inspection isn't possible. Domain-level filtering is the correct control.

---

## Summary of Gaps

| ID | Path | Issue | Severity | Fix |
|----|------|-------|----------|-----|
| G-1 | getUpdates inbound | No PromptGuard, no EncodingDetector — uses middleware only, not full pipeline | 🔴 HIGH | Wire pipeline.process_inbound() into _filter_inbound_updates |
| G-2 | MCP results | "Never blocked" policy — redacted but forwarded | 🟡 LOW | By design, but should log/alert on high-severity findings |
| G-3 | LLM proxy | No security pipeline on LLM responses | 🟡 LOW | Dead code — fix when activating |
| G-4 | Direct Telegram calls | 5 methods send directly to api.telegram.org | 🟡 MEDIUM | Route through _filter_outbound or use hardcoded-only text |
| G-5 | _notify_user_blocked | Forwards result.reason which may leak module names | 🟡 MEDIUM | Sanitize reason before sending |

---

## Will Fixing These Break Things?

### G-1 (Add pipeline.process_inbound to getUpdates):
**Risk:** PromptGuard may flag legitimate messages as injection. The webhook path already does this, so the behavior should be consistent. Owner exemption prevents owner messages from being blocked.
**Mitigation:** The pipeline already handles owner exemption. Non-owner messages that are currently unscanned will now be scanned — this is a security improvement, not a regression.

### G-4 (Route direct calls through outbound pipeline):
**Risk:** If the outbound pipeline blocks a gateway-generated message (disclosure notice, approval buttons), the UX breaks.
**Mitigation:** These messages are hardcoded text. The only dynamic one is `_notify_user_blocked(reason)`. Fix that one specifically by sanitizing the reason text, leave the hardcoded ones as-is.

### Outbound pipeline on all sendMessage (already done):
**Risk:** Over-redaction — the PII sanitizer might redact legitimate numbers in responses.
**Mitigation:** Owner messages use trust_level=FULL which can be configured to allow more disclosure. Monitor for false positives in the first few days.
