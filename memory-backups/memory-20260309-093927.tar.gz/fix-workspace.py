import sys
path = sys.argv[1]
with open(path, 'r') as f:
    c = f.read()
c = c.replace("workspace: 'collaborator-workspace'", "workspace: '/home/node/.openclaw/workspace/collaborator-workspace'")
with open(path, 'w') as f:
    f.write(c)
print("FIXED workspace path")
