#!/usr/bin/env python3
"""Update existing tests for new enforce defaults."""
import os

REPO = os.path.expanduser("~/Development/agentshroud")

def replace(path, old, new):
    full = os.path.join(REPO, path)
    with open(full) as f:
        content = f.read()
    assert old in content, f"Pattern not found in {path}: {old[:60]}"
    content = content.replace(old, new, 1)
    with open(full, 'w') as f:
        f.write(content)
    print(f"OK: {path}")

# 1. test_file_sandbox.py: test_default_mode_is_monitor -> test_default_mode_is_enforce
replace("gateway/tests/test_file_sandbox.py",
    '''    def test_default_mode_is_monitor(self, default_config):
        assert default_config.mode == "monitor"''',
    '''    def test_default_mode_is_enforce(self, default_config):
        assert default_config.mode == "enforce"''')

# 2. test_file_sandbox.py: test_workspace_write_allowed — /workspace is not in the default allowed paths for enforce
# The default allowed_write_default includes /tmp/**, /home/**, /app/data/**, /app/logs/**
# /workspace is NOT in there, so it gets blocked. Change the test path to /home/user/output.txt
replace("gateway/tests/test_file_sandbox.py",
    '''    def test_workspace_write_allowed(self, sandbox):
        v = sandbox.check_write(
            "/workspace/output.txt", agent_id="agent1", content="hello"
        )
        assert v.allowed is True''',
    '''    def test_workspace_write_allowed(self, sandbox):
        v = sandbox.check_write(
            "/home/user/output.txt", agent_id="agent1", content="hello"
        )
        assert v.allowed is True''')

# 3. test_file_sandbox.py: test_monitor_mode_allows_everything — now enforce is default, so this needs
# an explicit monitor-mode sandbox
replace("gateway/tests/test_file_sandbox.py",
    '''    def test_monitor_mode_allows_everything(self, sandbox):
        """Even blocked paths are allowed in monitor mode (just flagged)."""
        v = sandbox.check_read("/etc/shadow", agent_id="agent1")
        assert v.allowed is True
        assert v.flagged is True''',
    '''    def test_monitor_mode_allows_everything(self):
        """Even blocked paths are allowed in monitor mode (just flagged)."""
        monitor_sandbox = FileSandbox(config=FileSandboxConfig(mode="monitor"))
        v = monitor_sandbox.check_read("/etc/shadow", agent_id="agent1")
        assert v.allowed is True
        assert v.flagged is True''')

# 4. test_security_hardening.py: test_deny_all_false — need to find and fix
# Let me check what it looks like first
full = os.path.join(REPO, "gateway/tests/test_security_hardening.py")
with open(full) as f:
    content = f.read()

# Find the test_deny_all_false
idx = content.find("test_deny_all_false")
if idx >= 0:
    # Show context
    snippet = content[max(0, idx-100):idx+500]
    print(f"\nContext around test_deny_all_false:\n{snippet[:400]}")

print("\nDone")
