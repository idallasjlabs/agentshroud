#!/usr/bin/env python3
"""Round 2 hardening — apply all 9 fixes."""
import re, sys, os

REPO = os.path.expanduser("~/Development/agentshroud")

def read(path):
    with open(os.path.join(REPO, path)) as f:
        return f.read()

def write(path, content):
    with open(os.path.join(REPO, path), 'w') as f:
        f.write(content)

def replace(path, old, new, count=1):
    content = read(path)
    if old not in content:
        print(f"WARNING: pattern not found in {path}:\n  {old[:80]}")
        return False
    result = content.replace(old, new, count)
    if result == content:
        print(f"WARNING: no change in {path}")
        return False
    write(path, result)
    print(f"OK: {path}")
    return True

# === Fix 1: resource_guard.py — fail-closed on check_cpu_limit, check_memory_limit, check_disk_write_limit ===
print("\n=== Fix 1: resource_guard.py — fail-closed ===")

# check_cpu_limit
replace("gateway/security/resource_guard.py",
    '''        except Exception as e:
            logger.error(f"CPU check failed for agent {agent_id}: {e}")
            return True  # Allow by default on error''',
    '''        except Exception as e:
            logger.error(f"CPU check failed for agent {agent_id}: {e}")
            return False  # Fail-closed: deny on error''')

# check_memory_limit
replace("gateway/security/resource_guard.py",
    '''        except Exception as e:
            logger.error(f"Memory check failed for agent {agent_id}: {e}")
            return True''',
    '''        except Exception as e:
            logger.error(f"Memory check failed for agent {agent_id}: {e}")
            return False  # Fail-closed: deny on error''')

# check_disk_write_limit
replace("gateway/security/resource_guard.py",
    '''        except Exception as e:
            logger.error(f"Disk write check failed for agent {agent_id}: {e}")
            return True''',
    '''        except Exception as e:
            logger.error(f"Disk write check failed for agent {agent_id}: {e}")
            return False  # Fail-closed: deny on error''')

# === Fix 2: file_sandbox.py — default mode enforce ===
print("\n=== Fix 2: file_sandbox.py — default mode enforce ===")
replace("gateway/security/file_sandbox.py",
    '    mode: str = "monitor"  # "monitor" or "enforce"',
    '    mode: str = "enforce"  # "monitor" or "enforce"')

# === Fix 3: git_guard.py — default mode enforce ===
print("\n=== Fix 3: git_guard.py — default mode enforce ===")
replace("gateway/security/git_guard.py",
    '    def __init__(self, mode: str = "monitor"):',
    '    def __init__(self, mode: str = "enforce"):')

replace("gateway/security/git_guard.py",
    'def scan_repository(repo_path: str, mode: str = "monitor") -> GitGuard:',
    'def scan_repository(repo_path: str, mode: str = "enforce") -> GitGuard:')

# === Fix 4: egress_config.py — from_environment() default enforce ===
print("\n=== Fix 4: egress_config.py — from_environment() default enforce ===")
replace("gateway/security/egress_config.py",
    '        mode = "monitor"  # Default to monitor',
    '        mode = "enforce"  # Default to enforce (fail-closed)')

# === Fix 5: env_guard.py — fail-closed on parse exceptions ===
print("\n=== Fix 5: env_guard.py — fail-closed on parse exceptions ===")
replace("gateway/security/env_guard.py",
    '''        except Exception as e:
            logger.error(f"Error parsing command '{command}': {e}")
            # Allow execution if parsing fails to avoid breaking legitimate commands

        return True''',
    '''        except Exception as e:
            logger.error(f"Error parsing command '{command}': {e}")
            # Fail-closed: deny on parse error
            return False

        return True''')

# === Fix 6: DRY hardcoded owner chat ID ===
print("\n=== Fix 6: DRY hardcoded owner chat ID ===")

# Need to add RBACConfig import and use it
content = read("gateway/ingest_api/lifespan.py")

# Replace hardcoded "8096968754" on line 196
content = content.replace(
    '            admin_chat_id="8096968754" if _tg_token else None,',
    '            admin_chat_id=RBACConfig().owner_user_id if _tg_token else None,',
    1)

# Replace hardcoded "8096968754" on line 271
content = content.replace(
    '                owner_chat_id="8096968754",',
    '                owner_chat_id=RBACConfig().owner_user_id,',
    1)

# Add import near top if not already present
if 'from ..security.rbac_config import RBACConfig' not in content:
    # Find a good place to add it — after existing imports
    content = content.replace(
        'from ..approval_queue.store import ApprovalStore',
        'from ..security.rbac_config import RBACConfig\nfrom ..approval_queue.store import ApprovalStore',
        1)

write("gateway/ingest_api/lifespan.py", content)
print("OK: gateway/ingest_api/lifespan.py — owner chat ID DRYed")

# === Fix 7: LLMProxy dead endpoints — return "feature not enabled" ===
print("\n=== Fix 7: LLMProxy dead endpoints — feature not enabled ===")

content = read("gateway/ingest_api/main.py")

# Replace the entire llm_api_proxy function body after the not-llm_proxy check
old_llm_check = '''    llm_proxy = getattr(app_state, "llm_proxy", None)
    if not llm_proxy:
        raise HTTPException(status_code=503, detail="LLM proxy not available")

    body = await request.body() if request.method == "POST" else None
    headers = dict(request.headers)

    status_code, resp_headers, resp_body = await llm_proxy.proxy_messages(
        f"/v1/{path}", body, headers
    )

    # Check if streaming response
    content_type = resp_headers.get("content-type", "")
    if "text/event-stream" in content_type:
        from starlette.responses import StreamingResponse
        import io
        return StreamingResponse(
            io.BytesIO(resp_body),
            status_code=status_code,
            media_type="text/event-stream",
            headers={k: v for k, v in resp_headers.items() if k.lower() not in ("transfer-encoding", "content-length")},
        )

    return JSONResponse(
        content=json.loads(resp_body) if resp_body else {},
        status_code=status_code,
    )'''

new_llm_check = '''    return JSONResponse(
        content={"error": "LLM proxy feature is not enabled"},
        status_code=501,
    )'''

content = content.replace(old_llm_check, new_llm_check, 1)

# Replace llm_proxy_stats
old_stats = '''    llm_proxy = getattr(app_state, "llm_proxy", None)
    if not llm_proxy:
        return {"status": "not_initialized"}
    return llm_proxy.get_stats()'''

new_stats = '''    return JSONResponse(
        content={"error": "LLM proxy feature is not enabled"},
        status_code=501,
    )'''

content = content.replace(old_stats, new_stats, 1)
write("gateway/ingest_api/main.py", content)
print("OK: gateway/ingest_api/main.py — dead endpoints return 501")

# === Fix 8: Remove KeyVault dead code ===
print("\n=== Fix 8: Remove KeyVault dead code ===")

replace("gateway/ingest_api/lifespan.py",
    '''    # -- KeyVault: secure credential storage with audit trail --
    try:
        from ..security.key_vault import KeyVault, KeyVaultConfig
        app_state.key_vault = KeyVault(KeyVaultConfig())

        logger.info("✓ KeyVault initialized")
    except Exception as e:
        logger.error(f"✗ KeyVault: {e}")
        app_state.key_vault = None''',
    '''    # KeyVault removed — was instantiated but never wired to any consumer.
    # Re-add when a consumer (e.g. credential injector) needs it.''')

# === Fix 9: _notify_user_blocked — sanitize reason text ===
print("\n=== Fix 9: _notify_user_blocked — sanitize reason text ===")

content = read("gateway/proxy/telegram_proxy.py")

# Add a sanitize_reason helper method and update _notify_user_blocked
old_notify = '''    async def _notify_user_blocked(self, chat_id: int, reason: str):
        """Send a user-friendly notification when a message is blocked."""
        try:
            friendly_reasons = {
                "gitguard": "Your message contained patterns resembling code or script injection.",
                "promptguard": "Your message was flagged as a potential prompt injection attempt.",
                "prompt injection": "Your message was flagged as a potential prompt injection attempt.",
                "browsersecurity": "Your message contained a potentially unsafe browser payload.",
                "rbac": "You don\'t have permission to perform this action.",
                "contextguard": "Your message was flagged for context manipulation.",
                "filesandbox": "Your message referenced a restricted file path.",
            }
            user_msg = "Your message was blocked by a security filter."
            reason_lower = reason.lower()
            for key, friendly in friendly_reasons.items():
                if key in reason_lower:
                    user_msg = friendly
                    break

            notice = (
                "\u26a0\ufe0f *Message Blocked*\n\n"
                f"{user_msg}\n\n"
                f"_Reason: {reason}_\n\n"
                "If this is an error, contact the system owner."
            )'''

new_notify = '''    @staticmethod
    def _sanitize_reason(reason: str) -> str:
        """Strip internal module names, file paths, and class references from reason text."""
        import re as _re
        sanitized = reason
        # Remove Python module paths (e.g. gateway.security.foo_bar)
        sanitized = _re.sub(r'[a-zA-Z_][a-zA-Z0-9_]*(\.[a-zA-Z_][a-zA-Z0-9_]*){2,}', '[internal]', sanitized)
        # Remove file paths (e.g. /app/gateway/... or /home/...)
        sanitized = _re.sub(r'/[a-zA-Z0-9_./-]{3,}\.(py|yaml|yml|json|toml|cfg)', '[path]', sanitized)
        # Remove class::method references
        sanitized = _re.sub(r'[A-Z][a-zA-Z0-9]+::[a-zA-Z_]\w+', '[internal]', sanitized)
        # Remove traceback-style references
        sanitized = _re.sub(r'File "[^"]+",\s*line \d+', '[internal]', sanitized)
        # Collapse multiple [internal] markers
        sanitized = _re.sub(r'(\[internal\]\s*)+', '[internal] ', sanitized).strip()
        return sanitized

    async def _notify_user_blocked(self, chat_id: int, reason: str):
        """Send a user-friendly notification when a message is blocked."""
        try:
            friendly_reasons = {
                "gitguard": "Your message contained patterns resembling code or script injection.",
                "promptguard": "Your message was flagged as a potential prompt injection attempt.",
                "prompt injection": "Your message was flagged as a potential prompt injection attempt.",
                "browsersecurity": "Your message contained a potentially unsafe browser payload.",
                "rbac": "You don\'t have permission to perform this action.",
                "contextguard": "Your message was flagged for context manipulation.",
                "filesandbox": "Your message referenced a restricted file path.",
            }
            user_msg = "Your message was blocked by a security filter."
            reason_lower = reason.lower()
            for key, friendly in friendly_reasons.items():
                if key in reason_lower:
                    user_msg = friendly
                    break

            sanitized_reason = self._sanitize_reason(reason)
            notice = (
                "\u26a0\ufe0f *Message Blocked*\n\n"
                f"{user_msg}\n\n"
                f"_Reason: {sanitized_reason}_\n\n"
                "If this is an error, contact the system owner."
            )'''

content = content.replace(old_notify, new_notify, 1)
write("gateway/proxy/telegram_proxy.py", content)
print("OK: gateway/proxy/telegram_proxy.py — reason text sanitized")

print("\n=== All 9 fixes applied ===")
