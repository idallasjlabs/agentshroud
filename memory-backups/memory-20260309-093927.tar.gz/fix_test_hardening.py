#!/usr/bin/env python3
"""Fix test_security_hardening.py test_deny_all_false for enforce default."""
import os

REPO = os.path.expanduser("~/Development/agentshroud")
path = os.path.join(REPO, "gateway/tests/test_security_hardening.py")

with open(path) as f:
    content = f.read()

# The test creates EgressFilter with deny_all=False but doesn't set config mode.
# Now that default config mode is enforce, non-allowlisted domains get denied.
# Fix: pass a monitor-mode config to allow the deny_all=False to work as intended.
old = '''    def test_deny_all_false(self):
        policy = EgressPolicy(deny_all=False)
        ef = EgressFilter(default_policy=policy)
        result = ef.check("a", "anything.com", 443)
        assert result.action == EgressAction.ALLOW'''

new = '''    def test_deny_all_false(self):
        from gateway.security.egress_config import EgressFilterConfig
        policy = EgressPolicy(deny_all=False)
        config = EgressFilterConfig(mode="monitor")
        ef = EgressFilter(default_policy=policy, config=config)
        result = ef.check("a", "anything.com", 443)
        assert result.action == EgressAction.ALLOW'''

assert old in content, "Pattern not found"
content = content.replace(old, new, 1)

with open(path, 'w') as f:
    f.write(content)
print("Done")
