#!/usr/bin/env python3
"""Fix 9: Add _sanitize_reason and use it in _notify_user_blocked."""
import re, os

REPO = os.path.expanduser("~/Development/agentshroud")
path = os.path.join(REPO, "gateway/proxy/telegram_proxy.py")

with open(path) as f:
    content = f.read()

# 1. Add _sanitize_reason staticmethod before _notify_user_blocked
sanitize_method = '''    @staticmethod
    def _sanitize_reason(reason: str) -> str:
        """Strip internal module names, file paths, and class references from reason text."""
        sanitized = reason
        # Remove Python module paths (e.g. gateway.security.foo_bar)
        sanitized = re.sub(r'[a-zA-Z_][a-zA-Z0-9_]*(?:\\.[a-zA-Z_][a-zA-Z0-9_]*){2,}', '[internal]', sanitized)
        # Remove file paths (e.g. /app/gateway/... or /home/...)
        sanitized = re.sub(r'/[a-zA-Z0-9_./-]{3,}\\.(?:py|yaml|yml|json|toml|cfg)', '[path]', sanitized)
        # Remove class::method references
        sanitized = re.sub(r'[A-Z][a-zA-Z0-9]+::[a-zA-Z_]\\w+', '[internal]', sanitized)
        # Remove traceback-style references  
        sanitized = re.sub(r'File "[^"]+",\\s*line \\d+', '[internal]', sanitized)
        # Collapse multiple [internal] markers
        sanitized = re.sub(r'(\\[internal\\]\\s*)+', '[internal] ', sanitized).strip()
        return sanitized

'''

old_marker = '    async def _notify_user_blocked(self, chat_id: int, reason: str):'
assert old_marker in content, "_notify_user_blocked not found"
content = content.replace(old_marker, sanitize_method + old_marker, 1)

# 2. Replace reason with sanitized reason in the notice
old_reason_line = 'f"_Reason: {reason}_\\n\\n"'
new_reason_line = 'f"_Reason: {self._sanitize_reason(reason)}_\\n\\n"'
assert old_reason_line in content, f"reason line not found"
content = content.replace(old_reason_line, new_reason_line, 1)

with open(path, 'w') as f:
    f.write(content)

print("Fix 9 applied successfully")
