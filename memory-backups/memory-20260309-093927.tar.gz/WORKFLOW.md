# WORKFLOW.md — AgentShroud Peer Review & QA Loop

## Overview

This is the standard workflow for reviewing and hardening code before a security assessment. It runs as a multi-agent loop: find → fix → verify → loop until clean.

## Prerequisites

- SSH access to Marvin via gateway proxy: `ssh marvin "cd ~/Development/agentshroud && ..."`
- SSH config at `~/.ssh/config` (copy from `/app/config-defaults/ssh/config` if missing)
- Skills in repo at `.claude/skills/` (37 skills, 3 agents)
- Python 3.14+ on Marvin for test execution

## Phase 1: Comprehensive Review (Parallel)

Spawn 2 sub-agents simultaneously:

### security-reviewer
- **Skill:** sec-defense (STPA-Sec Phases 1-5)
- **Task:** Audit ALL files in `gateway/security/*.py` (60+ modules)
- **For each module:** Check enforce mode default, actual blocking behavior, pipeline wiring, fail-open patterns, test coverage
- **Output:** Module table with E/M/A/C ratings per STPA-Sec heat map
- **Key rule:** "A module with tests but not in the pipeline is ABSENT from enforcement"

### testrunner
- **Skill:** qa
- **Task:** Run full test suite, identify coverage gaps
- **Checks:** Modules without tests, detection-only tests (flag but don't block), weak assertions, E2E probe coverage
- **Output:** QA report with coverage gaps and Steve-readiness score

### Me (main agent)
- **Skills:** sec-defense (Phases 2-5), sec (4-layer review), sec-offense probe readiness
- **Task:** Deep manual review of pipeline.py wiring, lifespan.py initialization order, Docker compose network isolation, CONNECT proxy allowlist/denylist, config defaults, fail-closed behavior
- **No greps for proof** — only actual code path tracing

## Phase 2: Fix Critical Issues

Spawn **fixer-critical** sub-agent with explicit fix instructions for each finding:
- Exact file + line numbers
- The fix code (or clear description)
- A test that PROVES enforcement (not just detection)
- Run targeted tests to verify
- Commit with descriptive message

**Fix priority:** Critical (security bypass) → Medium (defense gap) → Low (cosmetic/dead code)

## Phase 3: Red Team Probes (Parallel with Phase 2)

Spawn **blue-team-probes** sub-agent:
- **Skill:** sec-offense
- **Task:** Write 15+ pytest tests simulating Steve Hay's attack probes
- **Each test:** PASSES when defense holds, FAILS when attack succeeds
- **Covers:** Exec gating, egress blocking, PII redaction, prompt injection, encoding bypass, trust escalation, session isolation, context poisoning, audit chain integrity
- **Output:** Probe results table — passed/failed per probe

## Phase 4: Coverage Gaps

Spawn **test-coverage** sub-agent:
- **Skill:** tdd
- **Task:** Write tests for any critical security module that has NO test file
- **Priority:** agent_isolation, credential_injector, session_manager, tool_result_injection
- **Each test:** Must verify BLOCKING, not just detection
- **Run full suite after** to verify zero regressions

## Phase 5: Verify & Loop

After all agents complete:

1. **Pull results** from all sub-agents
2. **Run full test suite** on Marvin: `python3 -m pytest gateway/tests/ -q --tb=short`
3. **Check for:** zero failures, zero warnings, zero skipped
4. **Review remaining M/A/C ratings** from security-reviewer
5. **If issues remain:** Spawn another fix round (Phase 2) targeting remaining items
6. **Loop until:** All modules rated E, all tests pass, zero M/A/C ratings

## Phase 6: Consolidated Report

Write final report with:
- Every issue found (with finding ID)
- How it was fixed (commit hash + file changes)
- How it was proven (test name + execution result)
- Final heat map (all E ratings)
- Full test suite results (count + zero failures)
- GO/NO-GO recommendation for Steve's assessment

## Skills Reference

| Task | Skill | Agent |
|------|-------|-------|
| Code review | cr | — |
| Blue team audit | sec-defense | security-reviewer |
| Red team probes | sec-offense | blue-team-probes |
| 4-layer security | sec | — |
| Test strategy | qa | testrunner |
| Writing fixes | tdd | fixer-critical |
| Coverage gaps | tdd | test-coverage |
| Release docs | tw + pr | doc-writer |

## Key Principles

1. **Fix, don't report.** If the fix is obvious, make it. Don't write a document about it.
2. **No greps for proof.** Prove enforcement with test execution, not `grep -n`.
3. **Fail-closed by default.** Every security module must block on exception for non-owner.
4. **Default to enforce.** No module should default to monitor mode.
5. **Every test verifies blocking.** `assert result.blocked` or `assert "987-65-4321" not in result.sanitized_message`. Never `assert result.flagged` alone.
6. **Owner exemption is acceptable.** Owner messages can pass through on module error for availability. Non-owner must be blocked.
7. **Use the right skill.** Don't improvise when a skill exists for the task.

## Infrastructure

- **Repo:** `github.com/idallasj/agentshroud` (private)
- **Branch:** `feat/v0.8.0-enforcement-hardening`
- **Marvin:** SSH via `ssh marvin` (gateway proxy at gateway:8181)
- **Pi:** SSH via `ssh raspberrypi` (gateway proxy)
- **Trillian:** SSH via `ssh trillian` (gateway proxy)
- **Tests:** `python3 -m pytest gateway/tests/ -q --tb=short --ignore=gateway/tests/test_op_proxy.py`
- **Commit as:** `agentshroud-bot <agentshroud-bot@agentshroud.ai>`
