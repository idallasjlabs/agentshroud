import sys

with open(sys.argv[1], 'r') as f:
    content = f.read()

# Fix 1: memorySearch boolean -> object, remove heartbeat
old_collab = "    workspace: 'collaborator-workspace',\n    memorySearch: false,\n    heartbeat: { enabled: false }"
new_collab = "    workspace: 'collaborator-workspace',\n    memorySearch: { enabled: false }"
content = content.replace(old_collab, new_collab)

# Fix 2: Add filesystem and web tools to deny list
old_deny = "        'image'\n      ]"
new_deny = "        'image', 'read', 'write', 'edit', 'apply_patch',\n        'ls', 'find', 'grep', 'web_search', 'web_fetch'\n      ]"
content = content.replace(old_deny, new_deny)

with open(sys.argv[1], 'w') as f:
    f.write(content)

print('PATCHED apply-patches.js')
