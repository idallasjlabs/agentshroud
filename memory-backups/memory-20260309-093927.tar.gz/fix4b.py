#!/usr/bin/env python3
"""Fix 4b: egress_config from_environment should also respect AGENTSHROUD_MODE=monitor."""
import os

REPO = os.path.expanduser("~/Development/agentshroud")
path = os.path.join(REPO, "gateway/security/egress_config.py")

with open(path) as f:
    content = f.read()

old = '''        agentshroud_mode = os.getenv("AGENTSHROUD_MODE", "").lower()
        if agentshroud_mode == "enforce":
            mode = "enforce"'''

new = '''        agentshroud_mode = os.getenv("AGENTSHROUD_MODE", "").lower()
        if agentshroud_mode in ("enforce", "monitor"):
            mode = agentshroud_mode'''

assert old in content, "Pattern not found"
content = content.replace(old, new, 1)

with open(path, 'w') as f:
    f.write(content)
print("Done")
