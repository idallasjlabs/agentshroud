# AgentShroud Gateway Security Module Review

**Date:** 2026-03-08  
**Reviewer:** Automated STPA-Sec Code Review (subagent)  
**Scope:** All 67 Python files in `gateway/security/*.py`  
**Methodology:** Static analysis of mode defaults, blocking behavior, fail-open patterns, pipeline integration, and test coverage

---

## STPA-Sec Verdict Legend

| Rating | Meaning |
|--------|---------|
| **E** | **Enforced** — blocks threats in enforce mode, wired into pipeline |
| **M** | **Monitor-only** — logs but doesn't block by default |
| **A** | **Absent** — not wired into any runtime pipeline |
| **C** | **Contradicted** — claims enforce but has bypass/fail-open |

---

## Critical Findings Summary

### 🔴 HIGH SEVERITY

1. **`egress_config.py` — `from_environment()` defaults to MONITOR** (line 124: `mode = "monitor"`). The dataclass default is `"enforce"`, but runtime instantiation via `get_egress_config()` calls `from_environment()` which defaults to monitor. **Mitigated** by `get_module_mode()` in lifespan which defaults to `"enforce"` when `AGENTSHROUD_MODE` is unset.

2. **`prompt_protection.py` — NOT IN PIPELINE.** Has tests, has redaction logic, but is never imported or called by any middleware, pipeline, or lifespan code. It exists in isolation.

3. **`heuristic_classifier.py` — NOT IN PIPELINE.** ML model loading is a placeholder (`"ML model loading not yet implemented"`). Only referenced in its own test file. Not called at runtime.

4. **`egress_filter.py` — `_notifier` is SET but NEVER CALLED from `check()`.** The notifier is wired in lifespan but `check()` never invokes it. Blocking notifications don't fire.

5. **`resource_guard.py` — FAIL-OPEN on ALL resource checks.** CPU check (line 244), memory check (line 263), and disk check (line 286) all `return True` (allow) on exception.

6. **`file_sandbox.py` — defaults to `mode="monitor"` (line 96).** In monitor mode, flagged operations are logged but allowed through.

7. **`git_guard.py` — defaults to `mode="monitor"` (line 53).** Suspicious files are logged but not quarantined.

### 🟡 MEDIUM SEVERITY

8. **`output_canary.py` — fail-open in pipeline** (pipeline.py line 581: `except Exception: logger.error()`). If canary check throws, response passes through unblocked.

9. **`tool_result_sanitizer_enhanced.py` — fail-open in pipeline** (pipeline.py line 549: `except Exception: logger.error()` with comment "Non-fatal — continue pipeline"). If sanitizer throws, unsanitized content passes through.

10. **`egress_config.py` `from_environment()` — dual default confusion.** Dataclass says `"enforce"`, factory function says `"monitor"`. Easy to instantiate wrong one.

---

## Complete Module Table

| # | Module | Default Mode | Enforce Blocks? | Fail-Open? | In Pipeline? | Has Block Tests? | Verdict |
|---|--------|-------------|----------------|-----------|-------------|-----------------|---------|
| 1 | `__init__.py` | N/A | N/A | N/A | N/A | N/A | — |
| 2 | `agent_isolation.py` | N/A (data) | N/A | No | No (registry) | No | A |
| 3 | `alert_dispatcher.py` | N/A (infra) | N/A | No | Infra only | No | A |
| 4 | `approval_hardening.py` | N/A | Yes (repeat blocking) | No | Via approval queue | Yes | E |
| 5 | `audit_export.py` | N/A (utility) | N/A | No | Logging only | No | — |
| 6 | `audit_store.py` | N/A (storage) | N/A | No | Logging only | No | — |
| 7 | `browser_security.py` | N/A | Yes (raises) | No | Direct raise | Yes | E |
| 8 | `canary.py` | N/A (health) | N/A | No | Health check | No | — |
| 9 | `canary_tripwire.py` | `block_on_detect=True` | Yes (blocks) | Minor (encoding exceptions swallowed) | Yes (pipeline step) | Yes | E |
| 10 | `clamav_scanner.py` | N/A (scanner) | N/A | No | Manual/cron | No | A |
| 11 | `collaborator_tracker.py` | N/A (logging) | N/A | Yes (swallows OSError) | Logging only | No | — |
| 12 | `consent_framework.py` | N/A | Yes (raises, returns False) | No | MCP consent | Yes | E |
| 13 | `context_guard.py` | N/A (always active) | Yes (returns `allowed=False`) | **No — fails closed** | **Yes (pipeline + middleware)** | Yes | **E** |
| 14 | `credential_injector.py` | N/A | Detects leaks (warns) | No | Credential mgmt | No | M |
| 15 | `dns_filter.py` | `mode="enforce"` | Yes (`allowed=False`) | No | Config-wired | Yes | E |
| 16 | `drift_detector.py` | N/A (monitoring) | N/A | No | Background scan | No | M |
| 17 | `egress_approval.py` | `ApprovalMode` | Yes (deny rules) | Yes (line 310: `except` logs error) | Yes (health route) | Yes | E |
| 18 | `egress_config.py` | **`"enforce"` (dataclass) / `"monitor"` (from_environment)** | Configures other modules | **DUAL DEFAULT** | Config module | Yes | **C** |
| 19 | `egress_filter.py` | Uses `egress_config` | Yes (DENY action) | No | **Yes (pipeline + lifespan)** | Yes | **E** |
| 20 | `egress_monitor.py` | `mode="enforce"` | Action="block" in enforce | No | Yes (middleware + web_proxy) | Yes | E |
| 21 | `encoding_detector.py` | N/A (utility) | N/A (detection only) | Minor (swallows decode errors) | Yes (pipeline recommended) | No | M |
| 22 | `encrypted_store.py` | N/A (crypto) | Raises on failure | No | Storage layer | No | — |
| 23 | `env_guard.py` | N/A (always blocks) | Yes (returns False) | Yes (line 190: `except` returns True) | Middleware | Yes | **C** |
| 24 | `falco_monitor.py` | N/A (monitoring) | N/A | Yes (swallows errors) | Background integration | No | M |
| 25 | `file_sandbox.py` | **`mode="monitor"`** | Yes (in enforce) | No | Yes (middleware) | Yes | **M** |
| 26 | `git_guard.py` | **`mode="monitor"`** | Yes (in enforce) | Yes (broad except) | Manual/scan | No | **M** |
| 27 | `health_report.py` | N/A (reporting) | N/A | No | Dashboard | No | — |
| 28 | `heuristic_classifier.py` | N/A | N/A (detection only) | No | **NOT IN PIPELINE** | Yes (detection) | **A** |
| 29 | `input_normalizer.py` | N/A (preprocessor) | N/A (normalization) | Yes (line 61: bare except) | Pre-scan utility | No | — |
| 30 | `key_rotation.py` | N/A (lifecycle) | N/A | Yes (many excepts) | Credential mgmt | No | — |
| 31 | `key_rotation_config.py` | N/A (config) | N/A | No | Config only | No | — |
| 32 | `key_vault.py` | N/A (storage) | Raises KeyError | No | Credential mgmt | No | — |
| 33 | `killswitch_config.py` | `dry_run=False` | Config only | No | Config module | No | — |
| 34 | `killswitch_monitor.py` | N/A | Dry-run tests only | Yes (many excepts) | Background monitor | No | M |
| 35 | `log_sanitizer.py` | N/A (filter) | N/A (sanitization) | Yes (bare except returns True) | All logging | No | — |
| 36 | `memory_config.py` | N/A (config) | N/A | No | Config module | No | — |
| 37 | `memory_integrity.py` | N/A (monitoring) | Alerts (critical log) | Yes (many excepts) | Background scan | No | M |
| 38 | `memory_lifecycle.py` | N/A (maintenance) | Blocks poisoned writes | Yes (broad excepts) | Background task | No | M |
| 39 | `metadata_guard.py` | N/A (sanitizer) | Strips headers | No | Yes (middleware) | No | E |
| 40 | `multi_turn_tracker.py` | `block_threshold=200.0` | Yes (blocks sessions) | **No — middleware fails closed** | **Yes (middleware)** | Yes | **E** |
| 41 | `network_validator.py` | N/A (auditor) | Reports findings | Yes (broad excepts) | Manual/scan | No | M |
| 42 | `oauth_security.py` | N/A | Yes (raises exceptions) | Yes (line 165: bare except returns False) | Auth flow | No | E |
| 43 | `outbound_filter.py` | `mode="enforce"` | Yes (redacts) | No | **Yes (pipeline)** | Yes | **E** |
| 44 | `outbound_filter_config.py` | `mode="enforce"` | Config only | No | Config module | No | — |
| 45 | `output_canary.py` | `block_on_detection=True` | Yes (in pipeline) | **Yes — pipeline catches exception, continues** | **Yes (pipeline)** | Yes (detection) | **C** |
| 46 | `path_isolation.py` | `block_base_directory_access=True` | Yes (blocks cross-user) | No | Session management | No | E |
| 47 | `progressive_trust_config.py` | N/A (config) | N/A | No | Config module | No | — |
| 48 | `prompt_guard.py` | `block_threshold=0.8` | Yes (blocks, returns `blocked=True`) | **No — pipeline has NO try/except** (fail-closed) | **Yes (pipeline + middleware)** | Yes | **E** |
| 49 | `prompt_protection.py` | N/A | Redacts (scan_response) | No | **NOT IN PIPELINE** | Yes (redaction) | **A** |
| 50 | `rbac.py` | N/A | Yes (`allowed=False`) | Yes (returns `allowed=False` on error) | Middleware | Yes | E |
| 51 | `rbac_config.py` | N/A (config) | N/A | No | Config module | No | — |
| 52 | `resource_guard.py` | N/A | Returns False on limits | **Yes — ALL resource checks return True on exception** | Background monitor | Yes | **C** |
| 53 | `session_manager.py` | N/A | Raises ValueError | No | Session management | No | — |
| 54 | `session_security.py` | N/A | Raises exceptions | No | Auth layer | No | E |
| 55 | `subagent_monitor.py` | `mode="enforce"` | Yes (raises, returns `allowed=False`) | No | Yes (middleware) | Yes | **E** |
| 56 | `token_validation.py` | N/A | Raises exceptions | No | Auth layer | No | E |
| 57 | `tool_chain_analyzer.py` | N/A (always active) | Yes (returns `False`) | **No — middleware fails closed** | **Yes (middleware)** | Yes | **E** |
| 58 | `tool_result_injection.py` | N/A (scanner) | Detection only | Yes (bare excepts) | Yes (middleware) | No | M |
| 59 | `tool_result_sanitizer.py` | `mode="enforce"` | Yes (strips) | No | Yes (pipeline) | No | E |
| 60 | `tool_result_sanitizer_enhanced.py` | `mode="enforce"` | Yes (strips links/images) | **Yes — pipeline catches exception, continues** | **Yes (pipeline)** | Yes | **C** |
| 61 | `trivy_report.py` | N/A (scanner) | N/A | Yes (timeouts) | Manual/cron | No | A |
| 62 | `trust_manager.py` | N/A | Denies on low trust | No | Yes (pipeline) | Yes | E |
| 63 | `wazuh_client.py` | N/A (monitoring) | N/A | Yes (swallows errors) | Background integration | No | M |
| 64 | `xml_leak_filter.py` | N/A (filter) | Yes (strips) | No | Post-processing | No | E |

---

## Priority Module Deep-Dive

### 🔴 `prompt_protection.py` — ABSENT (A)
- **Pipeline status:** NOT imported anywhere in middleware, pipeline, or lifespan
- **What it does:** Redacts system prompt content from outbound responses (SOUL.md, AGENTS.md patterns)
- **Risk:** System prompt leakage protection is **completely disconnected**
- **Recommendation:** Wire into `process_outbound()` in pipeline.py, after PII sanitization

### 🔴 `heuristic_classifier.py` — ABSENT (A)
- **Pipeline status:** NOT imported anywhere at runtime
- **What it does:** Heuristic + ML classification of injection attempts (ML portion is placeholder)
- **Risk:** Additional classification layer exists but provides zero runtime protection
- **Recommendation:** Integrate as pre-filter before PromptGuard, or deprecate

### 🟡 `egress_approval.py` — Enforced (E) with caveat
- **Pipeline status:** Wired via health route and approval queue infrastructure
- **Used in request path?** Not directly in the hot path — used for interactive approval flows
- **Risk:** Timeout path (line 306) returns without explicit deny/allow

### 🔴 `egress_filter.py` — Enforced (E) but notifier broken
- **Pipeline status:** Fully wired (lifespan → pipeline → middleware)
- **Does check() call _notifier?** **NO.** `_notifier` is set via `set_notifier()` but `check()` and `_record()` never call it. The Telegram notification on egress block is **dead code**.
- **Recommendation:** Add `self._notifier.notify(attempt)` in `_record()` when action is DENY

### 🟡 `output_canary.py` — Contradicted (C)
- **Pipeline status:** Wired in pipeline step 1.8
- **Exception behavior:** Pipeline wraps in try/except and logs error but **continues** (fail-open)
- **Block behavior:** Blocks on high/critical risk canary detection (good)
- **Risk:** Exception = prompt leakage goes undetected

### 🟡 `tool_result_sanitizer_enhanced.py` — Contradicted (C)
- **Pipeline status:** Wired in pipeline step 1.7
- **Exception behavior:** Pipeline catches exception and continues (fail-open, "Non-fatal")
- **Block behavior:** In enforce mode, strips non-allowlisted markdown links/images
- **Risk:** Exception = exfil URLs pass through unsanitized

---

## Fail-Open Risk Map

| Module | Exception Pattern | Impact |
|--------|------------------|--------|
| `resource_guard.py` | `return True` on CPU/memory/disk check failure | Agent bypasses resource limits |
| `output_canary.py` | Pipeline catches + continues | Prompt leakage undetected |
| `tool_result_sanitizer_enhanced.py` | Pipeline catches + continues | Exfil URLs pass through |
| `env_guard.py` | `return True` on parse error (line 190-194) | Env variable access allowed |
| `log_sanitizer.py` | Bare except returns True | Sensitive data in logs |
| `input_normalizer.py` | Bare except on URL decode | Encoded payloads not normalized |
| `egress_config.py` | `from_environment()` → monitor default | Egress not blocked without env var |

---

## Modules Defaulting to Monitor Mode

| Module | Line | Default | Risk |
|--------|------|---------|------|
| `file_sandbox.py` | 96 | `"monitor"` | File operations logged but not blocked |
| `git_guard.py` | 53 | `"monitor"` | Suspicious commits not quarantined |
| `egress_config.py` | 124 | `"monitor"` (in `from_environment()`) | Mitigated by `get_module_mode()` defaulting to enforce |
| `dns_filter.py` | 42 | `"enforce"` ✅ | Correct |
| `egress_monitor.py` | 73 | `"enforce"` ✅ | Correct |
| `subagent_monitor.py` | 61 | `"enforce"` ✅ | Correct |
| `outbound_filter.py` | 79 | `"enforce"` ✅ | Correct |
| `tool_result_sanitizer_enhanced.py` | 23 | `"enforce"` ✅ | Correct |

---

## Recommendations (Priority Order)

1. **🔴 CRITICAL:** Wire `prompt_protection.py` into the outbound pipeline — system prompt leakage is currently unprotected
2. **🔴 CRITICAL:** Fix `egress_filter._notifier` — add notification call in `_record()` when action=DENY
3. **🔴 HIGH:** Change `resource_guard.py` exception handlers from `return True` to `return False` (fail-closed)
4. **🔴 HIGH:** Change `env_guard.py` line 190 exception handler from `return True` to `return False`
5. **🟡 MEDIUM:** Make `output_canary` and `tool_result_sanitizer_enhanced` fail-closed in pipeline (block on exception)
6. **🟡 MEDIUM:** Change `file_sandbox.py` default to `mode="enforce"`
7. **🟡 MEDIUM:** Change `git_guard.py` default to `mode="enforce"`
8. **🟢 LOW:** Integrate or deprecate `heuristic_classifier.py` — currently dead code
9. **🟢 LOW:** Unify `egress_config.py` defaults — remove `mode = "monitor"` from `from_environment()` initial assignment

---

*Report generated by automated STPA-Sec security review. All findings verified against source code via SSH to development repository.*
