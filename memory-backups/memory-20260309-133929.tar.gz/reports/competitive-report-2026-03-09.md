# AgentShroud™ Competitive Intelligence Report

**Date:** March 9, 2026  
**Classification:** Internal — Shareable with Collaborators  
**Prepared by:** AgentShroud Intelligence

---

## Market Context

The AI agent security market is at an inflection point. Adoption is outpacing security across every metric.

| Metric | Value | Source |
|--------|-------|--------|
| AI Guardrails market (2024) | $0.7B | [Market.us Press Release](https://market.us/press-release/ai-guardrails-market/) |
| AI Guardrails market (2034 projected) | $109.9B (65.8% CAGR) | [Market.us Scoop](https://scoop.market.us/ai-guardrails-market-news/) |
| Enterprise AI market (2026) | $114.87B | [Mordor Intelligence](https://www.mordorintelligence.com/industry-reports/enterprise-ai-market) |
| Shadow AI breach cost (avg) | $4.63M (+$670K vs standard) | [IBM Cost of a Data Breach 2025](https://www.ibm.com/reports/data-breach); [Kiteworks analysis](https://www.kiteworks.com/cybersecurity-risk-management/ibm-2025-data-breach-report-ai-risks/) |
| MCP monthly SDK downloads | 97M+ (Python + TypeScript) | [MCP Official Blog](http://blog.modelcontextprotocol.io/); [BuildMVPFast](https://www.buildmvpfast.com/blog/model-context-protocol-mcp-guide-2026) |
| MCP CVEs filed (60-day window) | 30 | [Adversa AI — March 2026 Digest](https://adversa.ai/blog/top-mcp-security-resources-march-2026/) |
| Agents-to-humans ratio | 82:1 | [Palo Alto Networks 2026 Predictions](https://www.paloaltonetworks.com/blog/2025/11/2026-predictions-for-autonomous-ai/); [HBR Sponsored](https://hbr.org/sponsored/2025/12/6-cybersecurity-predictions-for-the-ai-economy-in-2026); [PR Newswire](https://www.prnewswire.com/news-releases/palo-alto-networks-forecasts-6-predictions-on-securing-the-new-ai-economy-for-2026-302617959.html) |
| Teams treating agents as independent identities | 22% | [Gravitee State of AI Agent Security 2026](https://www.gravitee.io/blog/state-of-ai-agent-security-2026-report-when-adoption-outpaces-control) (900+ respondents) |

### Regulatory Tailwind

- **NIST AI Agent Standards Initiative** launched February 2026 — formalizing agent interoperability and security standards. MCP compliance is appearing in federal RFPs.  
  Source: [NIST Announcement](https://www.nist.gov/news-events/news/2026/02/announcing-ai-agent-standards-initiative-interoperable-and-secure)

- **1Password CTO Nancy Wang:** "Baseline guardrails must be built into the platforms themselves."  
  Source: [Help Net Security](https://www.helpnetsecurity.com/2026/03/03/enterprise-ai-agent-security-2026/)

---

## Direct Competitors — Security Proxy / Gateway Layer

### 1. Lakera Guard 🟡 Closest Competitor

- **What:** Runtime AI security via single API call. Prompt injection detection, PII filtering, content moderation.
- **Positioning:** "AI Firewall" — well-funded, strong brand in enterprise AI security.
- **Gap vs AgentShroud:** API-level only. No full proxy architecture, no egress control, no tool-call inspection pipeline, no cross-turn correlation.
- **Link:** [https://www.lakera.ai/lakera-guard](https://www.lakera.ai/lakera-guard)

### 2. Prompt Security (Acquired by SentinelOne, August 5, 2025)

- **What:** Runtime GenAI protection — prompt injection, data leak prevention, shadow AI detection.
- **Positioning:** Now integrated into SentinelOne's endpoint/cloud security platform. Acquisition validates market category.
- **Gap vs AgentShroud:** Enterprise endpoint play, not agent-native proxy. Consolidation risk — product roadmap now driven by SentinelOne priorities.
- **Links:**
  - [Prompt Security Blog: Acquisition Announcement](https://prompt.security/blog/prompt-security-sentinelone-a-new-chapter-begins)
  - [SentinelOne Press Release](https://www.sentinelone.com/press/sentinelone-to-acquire-prompt-security-to-advance-genai-security/)
  - [SentinelOne Investor Relations](https://investors.sentinelone.com/press-releases/news-details/2025/SentinelOne-to-Acquire-Prompt-Security-to-Advance-GenAI-Security-and-Agent-Security-Strategy/default.aspx)

### 3. CalypsoAI

- **What:** Inference-time security platform — guardrails, compliance controls, DLP for GenAI applications.
- **Positioning:** Enterprise-focused, quote-based pricing. Protects chatbots, internal AI assistants, custom agents.
- **Gap vs AgentShroud:** No MCP proxy layer, no tool-call-level enforcement, no cross-turn correlation.
- **Link:** [https://www.reco.ai/compare/ai-security-tools-for-enterprises](https://www.reco.ai/compare/ai-security-tools-for-enterprises) (CalypsoAI section)

### 4. Lasso Security

- **What:** GenAI security platform — 50+ guardrails via API, LLM routing for 200+ models, visibility and runtime defense.
- **Positioning:** Broad coverage, developer-friendly API.
- **Gap vs AgentShroud:** Broad but shallow per-tool enforcement. No egress firewall, no RBAC at tool level.
- **Link:** [https://www.lasso.security](https://www.lasso.security)

### 5. Cequence AI Gateway 🟡 Adjacent Threat

- **What:** Converts any API into MCP-compatible endpoint. OAuth 2.1 identity-based agent access control. Sits between agents and enterprise backends.
- **Positioning:** "AI Easy Button" — enterprise API gateway extending to agentic AI.
- **Gap vs AgentShroud:** API gateway protecting backends FROM agents. Does not protect agents from themselves or inspect outbound agent behavior.
- **Links:**
  - [Cequence AI Gateway Product Page](https://www.cequence.ai/products/ai-gateway/)
  - [Cequence Guardrails Blog](https://www.cequence.ai/blog/ai/agentic-ai-security-guardrails/)

---

## Adjacent Players — Auth / Identity Layer

### 6. Arcade.dev ($12M Seed, March 2025)

- **What:** Agent auth & credential management — LLM never sees credentials. Just-in-time OAuth, managed auth flows. Authored core MCP auth capability.
- **Gap vs AgentShroud:** Auth only. No pipeline inspection, no prompt injection defense, no outbound filtering.
- **Links:**
  - [https://www.arcade.dev](https://www.arcade.dev)
  - [Funding Announcement (BusinessWire)](https://www.businesswire.com/news/home/20250318815130/en/Arcade.dev-Scores-12M-to-Solve-the-Biggest-Security-Problem-with-AI-Agents)

### 7. Okta — AI Identity Governance

- **What:** Treats AI agents as first-class identities with authentication, authorization, and lifecycle governance.
- **Gap vs AgentShroud:** Identity layer only. Doesn't inspect what agents DO with their identity.
- **Link:** [AI News — Best AI Security Solutions 2026](https://www.artificialintelligence-news.com/news/best-ai-security-solutions-2026-top-enterprise-platforms-compared/)

### 8. CyberArk

- **What:** Privileged access management extending to AI agents. Discovery, visibility, session control.
- **Gap vs AgentShroud:** PAM heritage — credential vaulting, not tool-call-level security pipeline.
- **Link:** [CyberArk Blog — AI Agent Security Market 2026](https://www.cyberark.com/resources/blog/whats-shaping-the-ai-agent-security-market-in-2026)

---

## Framework-Level Players

### 9. Gravitee

- **What:** API management platform moving into agent-aware gateway. Published "State of AI Agent Security 2026" report (900+ exec/practitioner respondents).
- **Key Finding:** Only 22% of teams treat agents as independent identities.
- **Links:**
  - [Report Blog Post](https://www.gravitee.io/blog/state-of-ai-agent-security-2026-report-when-adoption-outpaces-control)
  - [Full Report PDF](https://www.gravitee.io/hubfs/Downloadable%20Resource/state_of_ai_agent_security_report_pdf_2026.pdf)

### 10. Maxim AI (Bifrost)

- **What:** Enterprise AI gateway — routing, guardrails, observability.
- **Gap:** Observability-first. Security is a feature, not the architecture.
- **Link:** [https://www.getmaxim.ai](https://www.getmaxim.ai)

---

## AgentShroud Security Posture (v0.8.0)

### Strengths (Defensible Moat)

- **Full proxy architecture** — inbound + outbound pipeline, not just an API call
- **Tool-call-level inspection** via MCP proxy layer
- **Multi-layer pipeline:** ContextGuard → PII Sanitizer → EgressFilter → OutputCanary → AuditStore
- **RBAC** at agent/tool granularity
- **Credential isolation** (1Password integration, Docker secrets)
- **Cross-turn correlation** (20-turn window for multi-step attack detection)
- **Encoding detection** (base64/hex bypass defense)
- **Fail-closed defaults** (v0.8.0 Round 2)
- **2,458 tests passing**, 23/23 blue team probes defended

### Open Items

- PromptProtection & HeuristicClassifier not yet wired into pipeline
- PII redaction not yet demonstrated end-to-end
- 10 modules still converting from monitor → enforce defaults

---

## Strategic Positioning

No competitor operates at the proxy level for agent security. The market segments into:

| Segment | Players | What They Do | What They Don't Do |
|---------|---------|--------------|-------------------|
| API Guardrails | Lakera, CalypsoAI, Lasso | Single-call input/output filters | Full pipeline, egress control, tool-call inspection |
| Auth / Identity | Arcade, Okta, CyberArk | Who the agent IS | What the agent DOES with its identity |
| API Gateways | Cequence, Gravitee, Maxim | Protect backends from agents | Protect agents from themselves |

**AgentShroud is the only purpose-built security proxy that wraps the entire agent lifecycle:** inbound prompt → tool calls → outbound response → egress. That's the moat.

The MCP CVE explosion (30 in 60 days) and NIST standardization create urgency. Every MCP tool call is an attack vector. AgentShroud's proxy architecture is purpose-built for exactly this threat.

---

## Autonomous Agent / Bot Landscape

These are the platforms AgentShroud secures — the rapidly growing ecosystem of autonomous AI agents.

### 1. OpenClaw — The Dominant Platform

- **Stars:** 286,910 (as of March 9, 2026) — surpassed React; #14 all-time on GitHub
- **Latest:** v2026.3.8 (March 8, 2026) — ACP provenance metadata, backup/restore CLI, Brave LLM-context search, browser SSRF blocking, Teams authz hardening, script integrity binding
- **Context:** Has its own Wikipedia page. NIST and Shenzhen AI Bureau tracking. Grew from 1K stars (Jan 24) to 286K+ in 6 weeks.
- **Links:**
  - [GitHub — openclaw/openclaw](https://github.com/openclaw/openclaw) (286,910 ⭐)
  - [v2026.3.8 Release Notes](https://github.com/openclaw/openclaw/releases/tag/v2026.3.8)
  - [Wikipedia — OpenClaw](https://en.wikipedia.org/wiki/OpenClaw)
  - [Star History — OpenClaw Surpasses React](https://www.star-history.com/blog/openclaw-surpasses-react-most-starred-software)

### 2. PicoClaw — The Lightweight Challenger

- **Stars:** ~22,800 (overtook NanoClaw in popularity)
- **What:** Go-based. Built to run AI agents on $10 hardware with <10MB RAM. Launched Feb 9, 2026 — hit 5K stars in 4 days.
- **Status:** Now building multi-agent collaboration framework (Phase 1 roadmap, March 2026).
- **Links:**
  - [GitHub — sipeed/picoclaw](https://github.com/sipeed/picoclaw)
  - [March 2026 Roadmap (Issue #988)](https://github.com/sipeed/picoclaw/issues/988)

### 3. NanoClaw — The Security-First Alternative

- **Stars:** 18,000+ ([ZDNet, March 4, 2026](https://www.zdnet.com/article/nanoclaw-security-guide/))
- **What:** Lightweight OpenClaw alternative. Containerized by default for security. Runs on Anthropic's Agents SDK. Connects to WhatsApp, Telegram, Slack, Discord, Gmail. MIT license, launched January 31, 2026.
- **Press:** VentureBeat — "solves one of OpenClaw's biggest security issues"
- **Links:**
  - [GitHub — qwibitai/nanoclaw](https://github.com/qwibitai/nanoclaw)
  - [VentureBeat Coverage](https://venturebeat.com/orchestration/nanoclaw-solves-one-of-openclaws-biggest-security-issues-and-its-already)
  - [ZDNet Guide](https://www.zdnet.com/article/nanoclaw-security-guide/)

### 4. NanoBot — The Minimalist

- **Stars:** ~21,700
- **What:** From HKU Data Science Lab. Ultra-lightweight: ~4,000 lines of core agent code (99% smaller than OpenClaw). Python-based.
- **Links:**
  - [GitHub — HKUDS/nanobot](https://github.com/HKUDS/nanobot)
  - [Hacker News Discussion](https://news.ycombinator.com/item?id=46897737)

### 5. memU — The Memory Layer

- **What:** Agentic memory framework for 24/7 proactive agents. One API call for fully autonomous responses. Released on PyPI as `memu-py` (February 2026). Designed to plug into OpenClaw-style agents.
- **Links:**
  - [GitHub — NevaMind-AI/memU](https://github.com/NevaMind-AI/memU)
  - [memU Bot](https://memu.bot)
  - [memU Pro](https://memu.pro)

### 6. CrocBot — The Hardened Fork

- **What:** Telegram-first personal AI assistant. Simplified, hardened fork of OpenClaw with extracted features from Agent-Zero.
- **Link:** [GitHub — moshehbenavraham/crocbot](https://github.com/moshehbenavraham/crocbot)

---

## Key Macro Sources

| Topic | Source | Link |
|-------|--------|------|
| Agents outnumber humans 82:1 | Palo Alto Networks | [Blog](https://www.paloaltonetworks.com/blog/2025/11/2026-predictions-for-autonomous-ai/) / [HBR](https://hbr.org/sponsored/2025/12/6-cybersecurity-predictions-for-the-ai-economy-in-2026) |
| Built-in guardrails imperative | 1Password CTO (Nancy Wang) | [Help Net Security](https://www.helpnetsecurity.com/2026/03/03/enterprise-ai-agent-security-2026/) |
| AI no guardrails anymore | CNBC | [Article](https://www.cnbc.com/2026/02/28/ai-selloff-politics-agents.html) |
| Profits vs guardrails dilemma | Forbes | [Article](https://www.forbes.com/sites/geruiwang/2026/02/28/why-ai-safety-the-dilemma-of-profits-vs-guardrails/) |
| NIST Agent Standards Initiative | NIST | [Announcement](https://www.nist.gov/news-events/news/2026/02/announcing-ai-agent-standards-initiative-interoperable-and-secure) |
| MCP Security TOP 25 Vulnerabilities | Adversa AI | [Resource](https://adversa.ai/mcp-security-top-25-mcp-vulnerabilities/) |
| Shadow AI breach costs | IBM | [2025 Cost of a Data Breach Report](https://www.ibm.com/reports/data-breach) |
| OpenClaw alternatives comparison | Till Freitag | [Blog](https://till-freitag.com/en/blog/openclaw-alternatives-2026-en) |
| Claw ecosystem analysis | Medium (Ivan Ruzic, Ph.D.) | [Article](https://medium.com/@paraanchor/100-000-github-stars-in-seven-days-your-board-hasnt-heard-of-it-yet-171fddc64493) |

---

## Verification Notes

Every competitor, market figure, and statistic in this report was independently verified against primary sources. Each entry includes a direct link to the originating publication, press release, or product page.

**Specifically excluded:** "Zetherion AI" — referenced in a prior competitive scan but could not be verified as a real product after extensive search across GitHub, product directories, and news sources. Likely hallucinated by the original source.

---

*AgentShroud™ — Your agent can do anything — except get away with it.*

*© 2026 Isaiah Dallas Jefferson, Jr. All rights reserved.*
